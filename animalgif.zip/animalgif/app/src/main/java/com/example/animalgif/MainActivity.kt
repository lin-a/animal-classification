package com.example.animalgif

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.ByteArrayOutputStream


private const val URL = "http://10.0.2.2:5000/"

class MainActivity : AppCompatActivity() {

    companion object {
        const val CAMERA_REQUEST_CODE = 1
        const val LOAD_GALLERY = 2
        private var b64String = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // retrofit
        val retrofit= Retrofit.Builder()
            .baseUrl(URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        // api
        val api = retrofit.create(ApiService::class.java)


        // SELECT IMAGE button, displays dialog
        gallery_btn.setOnClickListener {
            withItems(this)
            animal.text = ""
        }

        predict_btn.setOnClickListener {

            // POST, send the content of image_view as a b64 string to flask api
            api.uploadImage(b64String).enqueue(object: Callback<GifResponse>{
                override fun onResponse(call: Call<GifResponse>, response: Response<GifResponse>) {
                    response.body()?.let { it1 -> displayGif(it1) }
                }

                override fun onFailure(call: Call<GifResponse>, t: Throwable) {
                    Toast.makeText(this@MainActivity,
                        "FAILED",
                        Toast.LENGTH_LONG).show()
                }
            })
        }
    }

    // display image after taking photo or select photo from gallery
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val image = data!!.extras?.get("data") as Bitmap
            image_view.setImageBitmap(image)
            b64String = bitmapToB64(image)
            /*
            Toast.makeText(this@MainActivity,
                b64String,
                Toast.LENGTH_LONG).show()
             */

        } else if (requestCode == LOAD_GALLERY && resultCode == Activity.RESULT_OK) {
            image_view.setImageURI(data!!.data)
            val source = data.data?.let { ImageDecoder.createSource(this.contentResolver, it) }
            val image = source?.let { ImageDecoder.decodeBitmap(it) }
            b64String = image?.let { bitmapToB64(it) }!!
            /*
            Toast.makeText(this@MainActivity,
                b64String,
                Toast.LENGTH_LONG).show()
             */
        }
    }

    // function to display alert dialog for choose image or take photo
    private fun withItems(context: Context) {

        val options = arrayOf("Take Photo", "Choose from Gallery", "Cancel")
        val builder = AlertDialog.Builder(this)
        with(builder)
        {
            setTitle("Choose Image")
            setItems(options) { dialog, which ->
                when (options[which]) {
                    "Take Photo" -> {
                        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                        startActivityForResult(intent, CAMERA_REQUEST_CODE)
                    }
                    "Choose from Gallery" -> {
                        val intent = Intent(
                            Intent.ACTION_PICK,
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        )
                        startActivityForResult(intent, LOAD_GALLERY)
                    }
                    "Cancel" -> {
                        dialog.dismiss()
                    }
                }
            }
            show()
        }
    }

    // display gif
    private fun displayGif(url: GifResponse) {
        val gif = image_view
        // display the animal
        animal.text = url.animal

        Glide.with(this)
            .asGif()
            .load(url.gif_url)
            .into(gif)
    }

    // convert Bitmap image file to base64 string
    private fun bitmapToB64(bm: Bitmap): String {
        val baos = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val b = baos.toByteArray()
        return Base64.encodeToString(b, Base64.DEFAULT)
    }
}
