package com.example.animalgif

data class GifResponse(
    val animal: String,
    val gif_url: String
)